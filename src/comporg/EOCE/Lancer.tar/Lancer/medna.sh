#!/bin/sh
rm -rf ~/.mednafen
mednafen $1

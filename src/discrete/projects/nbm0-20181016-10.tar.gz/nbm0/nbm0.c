#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

int main(int argc, char *argv[]){

	char baseray[36] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
	char *checkray;
	int *sumray;
	int *outray;
	int check     = 1;
	int inbase    = 0;
	int outbase   = 0;
	int basecount = 0;
	int count     = 0;
	int sum       = 0;

	inbase  = atoi(argv[1]);

	if(argc <= 3){
		fprintf(stderr, "Error!  Invalid number of arguments!\n");
		exit(1);
	} else if(inbase < 2 || inbase > 36){
		fprintf(stderr, "Error!  Invalid input base!\n");
		exit(2);
	}
	
	outbase = atoi(argv[3]);
	
	if(outbase < 2 || outbase > 36){
		fprintf(stderr, "Error!  Invalid output base!\n");
		exit(3);
	}
	
	//checking to see if argv[2] is in the right base
	checkray = (char *)malloc(sizeof((char *)strlen(argv[2])));
	checkray = strcpy(checkray, argv[2]);
	sumray = (int *)malloc(sizeof((int *)strlen(argv[2])));
	outray = (int *)malloc(sizeof((int *)strlen(argv[2])));
	int tmpcount = 0;

	for (count = strlen(checkray) - 1; count >= 0; count--){
		check = 1;
		basecount = 0;
		while (basecount < inbase && check != 0){
			if (checkray[count] == baseray[basecount]){
				sumray[tmpcount] = basecount;
				tmpcount++;
				check = 0;
			}
		basecount++;
		}
		if (check == 1){
			fprintf(stderr, "ERROR!  Number base is different than input!\n");
			exit(4);
		}

	}

	//go from input base to base10 for conversion ease
	basecount=0;
	for (count = strlen(checkray) - 1; count >= 0; count--){
		sum = sum + (sumray[basecount] * pow(inbase, basecount));
		basecount++;
	}
	//printf("sum is %d\n", sum);
	
	basecount=0;
	for (count = strlen(checkray) - 1; count >= 0; count--){
		check = sum%outbase;
		if (check != 0){	
			outray[count] = check;
		}
		sum = sum/outbase;
		//printf("outray at %d is %d\n",count, outray[count]);
		//printf("sum is %d\n", sum);
		basecount++;
	}
	count = 0;
	check = 0;
	while (count < basecount){
		if (outray[count] != 0 || check == 1){
			fprintf(stdout, "%c", baseray[outray[count]]);
			check = 1;
		}
		count++;
	}
	fprintf(stdout, "\n");
	
	//free(checkray);	
	//free(sumray);
	//free(outray);
	//free(baseray);
	return(0);
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
///////////////////////////////////////////////////////////////////////////////
int main(int argc, char **argv)
{
	// your implementation here (remove this comment)
	FILE *input;
	char content[255];
	struct winsize terminal;
   	ioctl  (0, TIOCGWINSZ, &terminal);
 
	if (terminal.ws_row < 20){
		printf("Error: Terminal height is less than 20 lines!\n");
		return(0);
	}
	
	if (terminal.ws_col < 80){
		printf("Error: Terminal width is less than 80 columns!\n");
		return(1);
	}

	
	if (argc == 1){
		printf("Error: Invalid number of arguments!\n");
	}else if (input = fopen(*(argv+1), "r")){
		printf("Size of file is: %d\n", sizeof(input));
		fgets(content, 17, (FILE*)input);
		printf("%s\n", content);
		printf("Size of output is: %d\n", sizeof(content));
		fclose(input);	
	} else {
		printf("Error: File does not exist!\n");
		return(2);
	}
	
  	//printf ("lines:   %d\n", terminal.ws_row);
   	//printf ("columns: %d\n", terminal.ws_col);
	return (0);
}

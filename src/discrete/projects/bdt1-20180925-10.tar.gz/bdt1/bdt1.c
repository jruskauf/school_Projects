#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define  ANSI_RESET             "\x1b[0m"
#define  ANSI_BOLD              "\x1b[1m"
#define  ANSI_FG_BLACK          "\x1b[30m"
#define  ANSI_FG_RED            "\x1b[31m"
#define  ANSI_FG_GREEN          "\x1b[32m"
#define  ANSI_FG_YELLOW         "\x1b[33m"
#define  ANSI_FG_BLUE           "\x1b[34m"
#define  ANSI_FG_MAGENTA        "\x1b[35m"
#define  ANSI_FG_CYAN           "\x1b[36m"
#define  ANSI_FG_WHITE          "\x1b[37m"
#define  ANSI_BG_BLACK          "\x1b[40m"
#define  ANSI_BG_RED            "\x1b[41m"
#define  ANSI_BG_GREEN          "\x1b[42m"
#define  ANSI_BG_YELLOW         "\x1b[43m"
#define  ANSI_BG_BLUE           "\x1b[44m"
#define  ANSI_BG_MAGENTA        "\x1b[45m"
#define  ANSI_BG_CYAN           "\x1b[46m"
#define  ANSI_BG_WHITE          "\x1b[47m"

int equalcheck(char compare1, char compare2);
void display(int *array1, int *array2, int *colorcheck, int gcount);

int main(int argc, char **argv)
{
	FILE *in1;
	FILE *in2;

	int  before1[16];
	int  before2[16];
	
	int forecolor[16];
	int colorcheck[16];

	int current1[16];
	int current2[16];

	int    count;
	int   gcount;
	char compare1;
	char compare2;
	char color;
	int check;


	//Can use memcpy to copy contents of a whole array to another
	//memcpy(copytoarray, copyfromarray, sizeof(copytoarray));
	
	if (argc == 1){
		fprintf(stderr, "ERROR: Only one file provided!\n");
	}

	if ((in1 = fopen(*(argv+1), "r")) && (in2 = fopen(*(argv+2), "r"))){
		//printf("Both files can be read\n");
		count = 0;
		gcount = 0;
		check = 0;
		while (!feof(in1) && !feof(in2)){
			if ((count == 16 && check == 1) && gcount > 16){
				display(before1, before2, forecolor, gcount-16);
				display(current1, current2, colorcheck, gcount);
				memcpy(forecolor, colorcheck, sizeof(forecolor));
				memcpy(before1, current1, sizeof(before1));
				memcpy(before2, current2, sizeof(before2));
				count= 0;
				if (gcount <= 32){
					check = 3;
				}else {
					check = 2;
				}
			} else if (count == 16 && check == 2){
				display(current1, current2, colorcheck, gcount);
				count = 0;
				check = 3;
			} else if (count == 16){
				memcpy(forecolor, colorcheck, sizeof(forecolor));
				memcpy(before1, current1, sizeof(before1));
				memcpy(before2, current2, sizeof(before2));
				count = 0;
			}
			compare1 = *(current1+count) = fgetc(in1);
			compare2 = *(current2+count) = fgetc(in2);
			color = *(colorcheck + count) = equalcheck (compare1, compare2);
			count++;
			gcount++;
			if (color != 0 && check == 0){
				check = 1;
			}
		}
		gcount--;	
		if (check == 1){
			display(before1, before2, forecolor, gcount-16);
			display(current1, current2, colorcheck, gcount);
		}

	}


	return (0);
}

int equalcheck (char compare1, char compare2){
	if (compare1 == compare2){
		return(0);
	} else {
		return(1);
	}
}

void display(int *array1, int *array2, int *colorcheck, int gcount){
	int countto = 16;
	gcount = gcount - 1;
	int count = 0;
	int skip = 0;
	char compare1;
	char compare2;
	char color;

	while(gcount%16 != 0){
		countto--;
		gcount++;	
	}

	printf("%08x: ", gcount-16);
	while(count <= countto){
		
		if (*(colorcheck+count) == 0){
			fprintf(stdout, "%02hhx", *(array1+count));
		} else {
			fprintf(stdout, ANSI_FG_GREEN);
			fprintf(stdout, "%02hhx", *(array1+count));
			fprintf(stdout, ANSI_RESET);
		}

		skip++;

		count++;

		if(skip == 2){
			fprintf(stdout," ");
			skip = 0;
		}		
	}
	
	count = countto;
	while (count < 15){
		fprintf(stdout, "  ");
		if (count%2 == 0){
			fprintf(stdout, " ");
		}
		skip++;
		count++;
	}


	fprintf(stdout, "| ");
	skip = 0;
	count = 0;

	while(count <= countto){

		if(skip == 2){
			fprintf(stdout," ");
			skip = 0;
		}		


		if (*(colorcheck+count) == 0){
			fprintf(stdout, "%02hhx", *(array2+count));
		} else {
			fprintf(stdout, ANSI_FG_GREEN);
			fprintf(stdout, "%02hhx", *(array2+count));
			fprintf(stdout, ANSI_RESET);
		}

		skip++;

		count++;

		}
	
	count = countto;
	while (count < 15){
		fprintf(stdout, "  ");
		if (count%2 == 0){
			fprintf(stdout," ");
		}
		skip++;
		count++;
	}	
	fprintf(stdout, "\n");
			
}


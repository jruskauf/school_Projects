#ifndef __UNIT_TOOLS_H
#define __UNIT_TOOLS_H
#define NAME    "unittools"
#define PRECIS  2
#define BUFFER  4096
#define VERSION "20180308-15"
#endif

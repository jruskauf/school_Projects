#ifndef _SUPPORT_H
#define _SUPPORT_H

// Function prototypes
//
void lscodes(code_t);

#endif

#include "list.h"

//////////////////////////////////////////////////////////////////////
//
//   obtain() - take and isolate indicated node out of list, through
//              a careful adjustment of necessary pointers. obtain()
//              needs to maintain list integrity.
//              
//error states: NULL or EMPTY initial list, NULL thatNode. In such a
//              case, do not modify the list.
//
// status code: this function can generate the following status codes
//                  DLN_NULL:    *thatNode is NULL
//                  DLN_INVALID: thatNode is NULL
//                  DLN_ERROR:   *thatNode not in list
//                  DLL_SUCCESS: normal operation
//                  DLL_NULL:    list is NULL
//                  DLL_ERROR:   error encountered (any error)
//                  DLL_INVALID: cannot proceed (myList is NULL)
//                  DLL_EMPTY:   list is EMPTY (not directly an
//                               error, although likely is associated
//                               with error condition)
//
//              as with the other functions, you may use no more
//              than one return() statement per function.
//
//              do not count; navigate by comparison
//
code_t  obtain(List **myList, Node **thatNode)
{
    code_t status = DLL_ERROR;

    if (myList != NULL){
	if((*myList) != NULL){
	    if((*myList) -> lead != NULL){
	        if(thatNode != NULL){
		    Node *tmp = NULL;
		    Node *tmp2 = NULL;
		    Node *tmp3 = NULL;
		    //status = find((*myList), (*thatNode) -> VALUE, &tmp);
	           /* if(status == DLN_SUCCESS){
			tmp3 = tmp -> right;
			tmp2 = tmp -> left;
			tmp2 -> right = tmp3;
			tmp3 -> left = tmp2;
			status = DLL_SUCCESS;
		    } else {
			status = status | DLN_ERROR | DLN_NULL;
		    }*/
	        }
	    } else {
		status = status | DLL_EMPTY;
	    }
	} else {
	    status = status | DLL_NULL;
	    thatNode = NULL;
	}
    } else {
	status = DLL_INVALID | status;
	thatNode = NULL;
    }
    return(status);
}
